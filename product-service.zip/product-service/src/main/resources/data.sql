insert into product(product_id, product_name ,status, unit_Price, user_Email)
values('CATALOG-001', 'Berlin', 'StopSell', 100, 'junseoho1029@gmail.com');