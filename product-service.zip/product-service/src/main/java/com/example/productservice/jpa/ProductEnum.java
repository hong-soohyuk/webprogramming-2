package com.example.productservice.jpa;

public enum ProductEnum {

    SoldOut ,  Sold , StopSell

}
