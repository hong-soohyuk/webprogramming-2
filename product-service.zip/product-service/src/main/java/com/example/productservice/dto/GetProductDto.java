package com.example.productservice.dto;

import lombok.Data;

@Data
public class GetProductDto {
    private String productId;
}
