package com.example.productservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
