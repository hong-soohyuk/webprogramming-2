package com.example.productservice.jpa;

public enum Status {
    SoldOut ,  Selling , Banned
}
